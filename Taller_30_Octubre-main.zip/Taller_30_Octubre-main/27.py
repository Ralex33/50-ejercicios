#27.	Escribe un algoritmo o el respectivo diagrama de flujo que lea dos números y determine el mayor de ellos.
print("Escriba dos numeros")
num1=int(input())
num2=int(input())
print("El mayor de los números es: ",max(num1,num2))