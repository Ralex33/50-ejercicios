#16.	Escribe un algoritmo o el respectivo diagrama de flujo que dada una cantidad de segundos indique cuántas horas representan

minutos=int(input("Ingrese los minutos que desea convertir a horas: "))
horas=minutos/60
print(minutos," minutos = {:.2f} horas".format(horas))
