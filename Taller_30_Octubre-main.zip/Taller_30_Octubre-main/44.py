#44.	Escribe un algoritmo o el respectivo diagrama de flujo que imprima los n primeros números naturales
n=int(input("¿Qué cantidad de números quiere imprimir?: "))
a=0
while a!=n:
    print(a)
    a+=1

