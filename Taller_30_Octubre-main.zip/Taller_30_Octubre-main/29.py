#29.	Escribe un algoritmo o el respectivo diagrama de flujo que lea tres números y determine el mayor y el menor de ellos.
print("Escriba tres numeros")
num1 = int(input())
num2 = int(input())
num3 = int(input())
print("El mayor de los números es: ", max(num1, num2, num3))
