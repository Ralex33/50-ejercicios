#21.	Escribe un algoritmo o el respectivo diagrama de flujo que lea un número y determine si es par o impar.
num=int(input("Ingrese un número: "))
if num%2==0:
    print("Es un número par")
else:
    print("Es un número impar")