#1.	Escribe un algoritmo o el respectivo diagrama de flujo para imprimir tu nombre y se le adicione un calificativo ingresado por el usuario. Por ejemplo: Carlos el crack o Juliana la mejor.
calificativo=input("Ingrese el calificativo que quiera: ")
print("Alexandra la",calificativo)