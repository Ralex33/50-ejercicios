#41.	Escribe un algoritmo o el respectivo diagrama de flujo que imprima los 10 primeros números naturales
for i in range(0,10):
    print(i)