#17.	Escribe un algoritmo o el respectivo diagrama de flujo que dada una cantidad de segundos indique cuántos minutos representan
segundos=int(input("Ingrese los minutos que desea convertir a minutos: "))
minutos=segundos/60
print(segundos, " segundos = ", " {:.2f} minutos".format(minutos))
