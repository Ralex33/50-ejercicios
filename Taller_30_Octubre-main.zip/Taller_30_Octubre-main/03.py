#3.	Escribe un algoritmo o el respectivo diagrama de flujo para imprimir la suma de dos números dados.
print("Ingrese dos números")
num_1=int(input())
num_2=int(input())
suma=num_1+num_2
print("La suma es=",suma)