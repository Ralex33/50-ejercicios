#9.	Escribe un algoritmo o el respectivo diagrama de flujo que dados tres números calcule el promedio de dichos números.
print("Ingrese tres números para calcularles su promedio:")
num1=int(input())
num2=int(input())
num3=int(input())
promedio=(num1+num2+num3)/3
print("El promedio de los número es = {:.2f}".format(promedio))
