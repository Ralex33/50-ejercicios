#Escribe un algoritmo o el respectivo diagrama de flujo para imprimir el cuadrado de un número dado.
numero=int(input("Ingrese un número para calcularle su cuadrado: "))
cuadrado=numero**2
print("El cuadrado del núemero es =",cuadrado)