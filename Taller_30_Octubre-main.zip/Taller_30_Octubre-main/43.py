#43.	Escribe un algoritmo o el respectivo diagrama de flujo que imprima los primeros 10 números naturales pares
n = 0
a = 0
while n < 10:
    print(a)
    a += 2
    n += 1
