#22.	Escribe un algoritmo o el respectivo diagrama de flujo que lea un número y determine si es positivo o negativo
num = int(input("Ingrese un número: "))
if num >=0:
    print(num,"Es un número positivo")
else:
    print(num,"Es un número negativo")
