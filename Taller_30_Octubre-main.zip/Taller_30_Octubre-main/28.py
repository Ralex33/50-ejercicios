#28.	Escribe un algoritmo o el respectivo diagrama de flujo que lea un número y lo convierta a decimal.
print("Escriba un número entero para convertirlo en decimal: ")
nument=int(input())
numdec=float(nument)
print(nument,"--->",numdec)